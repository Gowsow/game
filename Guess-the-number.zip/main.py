#guess the number
import random
compnum= random.randint(1,20)
name = input("Hello, what is your name?")
print("Hello",name,"I am thinking of a number between 1 and 20.You have a maximum of 6 tries to guess the number.If you guess it wrong I will hack your account and get all your private things.")
guesses=0
for guess in range(6):
  print("take a guess")
  num= int(input())
  guess+=1
  if num > compnum:
    print("Your guess is too high!")
  elif num < compnum:
    print("Your guess is too low")
  else:
    break
if compnum==num:
  #guesses+=1
   print("Good Job!!! Your guess is right!!!!",guess,"tries")
if compnum != num:
  print ('Nope. The number I was thinking of was', compnum)